
//resenje jedan
/*let n=0;
for (let index = 0; index >=0; index+=2) {
    function ping(n){
        console.log('ping', n);
    }
    function pong(n){
        n++;
        console.log('pong', n);
    }
    n+=2;
        ping(n);
        pong(n);
}
*/


//resenje dva
  /*for (let index = 0; index >=0; index++) {
    let ping=index;
    let pong=index+1;
    console.log('ping ', ping);
    console.log('pong ', pong);
    
  }*/
  
  //polazno ressenje
  /*  function ping(n){
    console.log('ping', n);
    return pong(n+1);
}
function pong(n){
    console.log('pong', n);
    return ping(n + 1);
}

    ping(0);

//ping 0
//pong 1
//ping 2
//...
//ping 9155
//pong 9156
//Uncaught RangeError: Maximum call stack size exceeded
/*
